package com.covidTracker.coronavirustacker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronavirusTackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
